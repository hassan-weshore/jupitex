<?php
// Print Products Grid Extended
function thegem_products_grid_extended($params) {
	global $post;
	$portfolio_posttemp = $post;

	wp_enqueue_style('thegem-portfolio-products-extended');
	wp_enqueue_script('thegem-portfolio-products-extended');

	$grid_uid = $params['portfolio_uid'];

	$localize = array(
		'data' => $params,
		'action' => 'extended_products_grid_load_more',
		'url' => admin_url('admin-ajax.php'),
		'nonce' => wp_create_nonce('extended_products_grid_ajax-nonce')
	);
	wp_localize_script('thegem-portfolio-products-extended', 'thegem_portfolio_ajax_' . $params['portfolio_uid'], $localize);

	if ($params['select_products_categories'] == '1') {
		$categories = explode(",", $params['content_products_cat']);
	} else {
		$categories = ['0'];
	}

	$cat_args = array(
		'hide_empty' => true,
		'orderby' => $params['filter_by_categories_order_by']
	);
	if ($params['filter_by_categories_order_by'] == 'term_order') {
		$cat_args['orderby'] = 'meta_value_num';
		$cat_args['meta_key'] = 'order';
	}

	if (in_array('0', $categories)) {
		if ($params['filter_by_categories_hierarchy'] == '1') {
			$cat_args['parent'] = 0;
			$terms = get_terms('product_cat', $cat_args);
		} else {
			$terms = get_terms('product_cat', $cat_args);
		}
	} else {
		$cat_args['slug'] = $categories;
		$terms = get_terms('product_cat', $cat_args);
	}

	$categories_filter = null;
	if (isset($_GET[$grid_uid . '-category'])) {
		$active_cat = $_GET[$grid_uid . '-category'];
		$categories_current = [$active_cat];
		$categories_filter = $active_cat;
	} else {
		$active_cat = 'all';
		$categories_current = $categories;
	}

	$attributes = [];
	if ($params['select_products_attributes'] == '1') {
		$attrs = explode(",", $params['content_products_attr']);

		if ($attrs) {
			foreach ($attrs as $attr) {
				$values = explode(",", $params['content_products_attr_val_' . $attr]);
				if (in_array('0', $values) || empty($values)) {
					$values = get_terms('pa_' . $attr, array('fields' => 'slugs'));
				}
				$attributes[$attr] = $values;
			}
		}
	}

	$attributes_url = [];
	$has_attr_url = false;
	$attributes_list = get_woo_attribute_productGrid();
	foreach ($attributes_list as $name => $attr) {
		if (isset($_GET[$grid_uid . '-filter_' . $attr])) {
			$attributes_url[$attr] = explode(",", $_GET[$grid_uid . '-filter_' . $attr]);
			$has_attr_url = true;
		}
	}
	$attributes_filter = null;
	if ($has_attr_url) {
		$attributes_current = $attributes_url;
		$attributes_filter = $attributes_url;
	} else {
		$attributes_current = $attributes;
	}

	if ($params['caption_position'] == 'image') {
		$hover_effect = $params['image_hover_effect_image'];
	} else if ($params['caption_position'] == 'page') {
		$hover_effect = $params['image_hover_effect_page'];
	} else {
		$hover_effect = $params['image_hover_effect_hover'];
	}

	wp_enqueue_style('thegem-hovers-' . $hover_effect);

	if ($params['pagination_type'] == 'more') {
		wp_enqueue_style('thegem-button');
	} else if ($params['pagination_type'] == 'scroll') {
		wp_enqueue_script('thegem-scroll-monitor');
	}

	if ($params['quick_view'] == '1') {
		wp_enqueue_script('wc-single-product');
		wp_enqueue_script('wc-add-to-cart-variation');
		wp_enqueue_script('thegem-product-quick-view');
		if (thegem_get_option('product_gallery') != 'legacy') {
			wp_enqueue_style('thegem-product-gallery');
		} else {
			wp_enqueue_style('thegem-hovers');
		}
	}

	if ($params['product_show_filter'] === '1') {
		wp_enqueue_script('jquery-dlmenu');

		if ($params['filter_by_price'] === '1') {
			wp_enqueue_script('wc-jquery-ui-touchpunch');
		}
	}

	if ($params['loading_animation'] === '1') {
		wp_enqueue_style('thegem-animations');
		wp_enqueue_script('thegem-items-animations');
		wp_enqueue_script('thegem-scroll-monitor');
	}

	if ($params['layout'] !== 'justified' || $params['ignore_highlights'] !== '1') {

		if ($params['layout'] == 'metro') {
			wp_enqueue_script('thegem-isotope-metro');
		} else {
			wp_enqueue_script('thegem-isotope-masonry-custom');
		}
	}

	$items_per_page = intval($params['items_per_page']);
	if ($items_per_page == 0) {
		$items_per_page = 8;
	}

	$page = 1;
	$next_page = 0;
	if (isset($_GET[$grid_uid . '-page'])) {
		$page = $_GET[$grid_uid . '-page'];
	}

	if (isset($_GET[$grid_uid . '-orderby'])) {
		$orderby = $_GET[$grid_uid . '-orderby'];
		$order = 'desc';
		$sortby = $orderby;
		if ($sortby == 'price' || $sortby == 'title') {
			$order = 'asc';
		}
	} else {
		$orderby = $params['orderby'];
		$order = $params['order'];
		$sortby = 'default';
	}

	$featured_only = $params['featured_only'] == '1' ? true : false;
	$sale_only = $params['sale_only'] == '1' ? true : false;
	$stock_only = false;

	$status_current = null;
	if (isset($_GET[$grid_uid . '-status'])) {
		$status_current = explode(",", $_GET[$grid_uid . '-status']);
		if (in_array('sale', $status_current)) {
			$sale_only = true;
		}
		if (in_array('stock', $status_current)) {
			$stock_only = true;
		}
	}

	$price_current = null;
	if (isset($_GET[$grid_uid . '-min_price']) || isset($_GET[$grid_uid . '-max_price'])) {
		$price_range = thegem_extended_products_get_product_price_range($featured_only, $sale_only, $categories, $attributes);
		$current_min_price = isset($_GET[$grid_uid . '-min_price']) ? floatval($_GET[$grid_uid . '-min_price']) : $price_range['min'];
		$current_max_price = isset($_GET[$grid_uid . '-max_price']) ? floatval($_GET[$grid_uid . '-max_price']) : $price_range['max'];
		$price_current = [$current_min_price, $current_max_price];
	}

	$search_current = null;
	if (isset($_GET[$grid_uid . '-product-search'])) {
		$search_current = $_GET[$grid_uid . '-product-search'];
	}

	if ($params['product_show_filter'] == '1' && $params['filters_style'] == 'tabs') {
		if (isset($_GET[$grid_uid . '-tab'])) {
			$active_tab = intval($_GET[$grid_uid . '-tab']);
		} else {
			$active_tab = 1;
		}

		$filter_tabs = vc_param_group_parse_atts($params['filters_tabs_tabs']);
		$filter_tabs_current = $filter_tabs[$active_tab - 1];
		if ($filter_tabs_current['filters_tabs_tab_filter_by'] == 'featured') {
			$featured_only = true;
		} else if ($filter_tabs_current['filters_tabs_tab_filter_by'] == 'sale') {
			$sale_only = true;
		} else if ($filter_tabs_current['filters_tabs_tab_filter_by'] == 'recent') {
			$orderby = 'date';
			$order = 'desc';
		} else if ($filter_tabs_current['filters_tabs_tab_filter_by'] == 'categories') {
			$categories_current = [$filter_tabs_current['filters_tabs_tab_products_cat']];
		}
	}

	if ($params['add_to_cart_type'] == 'buttons') {
		$params['add_to_cart_type'] = 'button';
	}

	$product_loop = thegem_extended_products_get_posts($page, $items_per_page, $orderby, $order, $featured_only, $sale_only, $stock_only, $categories_current, $attributes_current, $price_current, $search_current);

	if ($product_loop && $product_loop->have_posts() || $search_current != null || $price_current != null) :

		echo thegem_extended_products_render_styles($params);

		if (ceil($product_loop->found_posts / $items_per_page) > $page)
			$next_page = $page + 1;
		else
			$next_page = 0;

		$max_page = $product_loop->max_num_pages;

		$item_classes = get_thegem_extended_products_render_item_classes($params);
		$thegem_sizes = get_thegem_extended_products_render_item_image_sizes($params);

		$search_only = true;
		if ($params['product_show_filter'] == '1' && (
				($params['filter_by_categories'] == '1' && count($terms) > 0) ||
				$params['filter_by_attribute'] == '1' ||
				$params['filter_by_price'] == '1' ||
				$params['filter_by_status'] == '1'
			)) {
			$search_only = false;
		}

		if ($params['columns_desktop'] == '100%') {
			echo apply_filters('thegem_portfolio_preloader_html', '<div class="preloader save-space"><div class="preloader-spin"></div></div>');
		} else if ($params['skeleton_loader'] == '1' || $params['layout'] !== 'justified' || $params['ignore_highlights'] !== '1') { ?>
			<div class="preloader save-space skeleton panel-sidebar-position-<?php echo $params['sidebar_position']; ?>">
				<?php if ($params['product_show_filter'] == '1' && $params['filters_style'] == 'sidebar' && !$search_only) { ?>
				<div class="with-filter-sidebar">
					<div class="filter-sidebar">
						<div class="widget"></div>
						<div class="widget"></div>
						<div class="widget"></div>
					</div>
					<div class="content">
						<?php }
						if ($params['product_show_sorting'] == '1') { ?>
							<div class="portfolio-top-panel">
								<div class="skeleton-sorting"></div>
							</div>
						<?php } ?>
						<div class="skeleton-posts row portfolio-row">
							<?php for ($x = 0; $x < $items_per_page; $x++) {
								echo thegem_extended_products_render_item($params, $item_classes);
							} ?>
						</div>
						<?php if ($params['product_show_filter'] == '1' && $params['filters_style'] == 'sidebar' && !$search_only) { ?>
					</div>
				</div>
			<?php } ?>
			</div>
		<?php } ?>

		<div class="portfolio-preloader-wrapper panel-sidebar-position-<?php echo $params['sidebar_position']; ?> ">

			<?php
			if ($params['caption_position'] == 'hover') {
				$title_on = 'hover';
			} else {
				$title_on = 'page';
			}

			$portfolio_classes = array(
				'portfolio portfolio-grid extended-products-grid',
				'woocommerce',
				'products',
				'no-padding',
				'portfolio-preset-' . $params['extended_grid_skin'],
				'portfolio-pagination-' . $params['pagination_type'],
				'portfolio-style-' . $params['layout'],
				'background-style-' . $params['caption_container_preset'],
				(($params['caption_position'] == 'hover' && ($params['image_hover_effect_hover'] == 'slide' || $params['image_hover_effect_hover'] == 'fade')) || $params['caption_position'] == 'image') ? 'caption-container-preset-' . $params['caption_container_preset_hover'] : '',
				(($params['caption_position'] == 'hover' && ($params['image_hover_effect_hover'] == 'slide' || $params['image_hover_effect_hover'] == 'fade')) || $params['caption_position'] == 'image') ? 'caption-alignment-' . $params['caption_container_alignment_hover'] : '',
				'caption-position-' . $params['caption_position'],
				'aspect-ratio-' . $params['image_aspect_ratio'],
				'hover-' . $hover_effect,
				'title-on-' . $title_on,
				($params['loading_animation'] == '1' ? 'loading-animation' : ''),
				($params['loading_animation'] == '1' && $params['animation_effect'] ? 'item-animation-' . $params['animation_effect'] : ''),
				($params['image_gaps'] == 0 ? 'no-gaps' : ''),
				($params['columns_desktop'] == '100%' ? 'fullwidth-columns fullwidth-columns-desktop-' . $params['columns_100'] : ''),
				($params['caption_position'] == 'image' && $params['image_hover_effect_image'] == 'gradient' ? 'hover-gradient-title' : ''),
				($params['caption_position'] == 'image' && $params['image_hover_effect_image'] == 'circular' ? 'hover-circular-title' : ''),
				($params['caption_position'] == 'hover' || $params['caption_position'] == 'image' ? 'hover-title' : ''),
				($params['social_sharing'] != '1' ? 'portfolio-disable-socials' : ''),
				($params['layout'] == 'masonry' ? 'portfolio-items-masonry' : ''),
				($params['columns_desktop'] != '100%' ? 'columns-desktop-' . $params['columns_desktop'] : 'columns-desktop-' . $params['columns_100']),
				('columns-tablet-' . $params['columns_tablet']),
				('columns-mobile-' . $params['columns_mobile']),
				($params['product_separator'] == '1' ? 'item-separator' : ''),
				($params['layout'] == 'justified' && $params['ignore_highlights'] == '1' ? 'disable-isotope' : ''),
			);
			?>

			<div id="<?php echo esc_attr($grid_uid) ?>" class="<?php echo esc_attr(implode(' ', $portfolio_classes)) ?>"
				 data-per-page="<?php echo esc_attr($items_per_page) ?>"
				 data-current-page="<?php echo esc_attr($page) ?>"
				 data-next-page="<?php echo esc_attr($next_page) ?>"
				 data-pages-count="<?php echo esc_attr($max_page) ?>"
				 data-portfolio-uid="<?php echo esc_attr($grid_uid) ?>"
				 data-hover="<?php echo esc_attr($hover_effect) ?>"
				 data-portfolio-filter='<?php echo esc_attr($categories_filter) ?>'
				 data-portfolio-filter-attributes='<?php echo esc_attr(json_encode($attributes_filter)) ?>'
				 data-portfolio-filter-status='<?php echo esc_attr(json_encode($status_current)) ?>'
				 data-portfolio-filter-price='<?php echo esc_attr(json_encode($price_current)) ?>'
				 data-portfolio-filter-search='<?php echo esc_attr($search_current) ?>'>
				<?php
				$show_widgets = false;
				$has_right_panel = ($params['product_show_sorting'] == '1' || ($params['filter_by_search'] == '1' && ($params['filters_style'] == 'standard' || $search_only))) ? true : false; ?>

				<div class="portfolio-row-outer <?php if ($params['columns_desktop'] == '100%'): ?>fullwidth-block no-paddings<?php endif; ?>">
					<?php if ($params['product_show_filter'] == '1' && $params['filters_style'] == 'sidebar' && !$search_only) { ?>
					<div class="with-filter-sidebar">
						<div class="filter-sidebar <?php echo $params['product_show_sorting'] == '1' ? 'left' : ''; ?>">
							<?php include(locate_template(array('gem-templates/products-extended/filters.php'))); ?>
						</div>
						<div class="content">
							<?php } ?>
							<?php if (($params['product_show_filter'] == '1' || $params['product_show_sorting'] == '1') && $params['filters_style'] != 'tabs'): ?>
								<div class="portfolio-top-panel <?php echo $params['filters_style'] == 'sidebar' ? 'sidebar-filter' : ''; ?> <?php echo ($params['product_show_sorting'] != '1' && $params['filter_by_search'] != '1') ? 'selected-only' : ''; ?>">
									<div class="portfolio-top-panel-row">
										<div class="portfolio-top-panel-left <?php echo esc_attr($params['filter_buttons_standard_alignment']); ?>">
											<?php
											if ($params['product_show_filter'] == '1' && $params['filters_style'] != 'sidebar' && !$search_only) {
												include(locate_template(array('gem-templates/products-extended/filters.php')));
											}
											if (($params['product_show_filter'] == '1' && $params['filters_style'] == 'sidebar') || $params['product_show_filter'] != '1') {
												include(locate_template(array('gem-templates/products-extended/selected-filters.php')));
											} ?>
										</div>
										<?php if ($has_right_panel): ?>
											<div class="portfolio-top-panel-right">
												<?php if ($params['product_show_sorting'] == '1'): ?>
													<div class="portfolio-sorting-select">
														<div class="portfolio-sorting-select-current">
															<div class="portfolio-sorting-select-name">
																<?php
																switch ($sortby) {
																	case "date":
																		echo esc_html($params["sorting_dropdown_latest_text"]);
																		break;
																	case "popularity":
																		echo esc_html($params["sorting_dropdown_popularity_text"]);
																		break;
																	case "rating":
																		echo esc_html($params["sorting_dropdown_rating_text"]);
																		break;
																	case "price":
																		echo esc_html($params["sorting_dropdown_price_low_high_text"]);
																		break;
																	case "price-desc":
																		echo esc_html($params["sorting_dropdown_price_high_low_text"]);
																		break;
																	default:
																		echo esc_html($params['sorting_text']);
																} ?>
															</div>
															<span class="portfolio-sorting-select-current-arrow"></span>
														</div>
														<ul>
															<li class="default <?php echo $sortby == 'default' ? 'portfolio-sorting-select-current' : ''; ?>"
																data-orderby="<?php echo esc_attr($params['orderby']); ?>"
																data-order="<?php echo esc_attr($params['order']); ?>"><?php echo esc_html($params['sorting_text']); ?></li>
															<li class="<?php echo $sortby == 'date' ? 'portfolio-sorting-select-current' : ''; ?>"
																data-orderby="date"
																data-order="desc"><?php echo esc_html($params['sorting_dropdown_latest_text']); ?>
															</li>
															<li class="<?php echo $sortby == 'popularity' ? 'portfolio-sorting-select-current' : ''; ?>"
																data-orderby="popularity"
																data-order="desc"><?php echo esc_html($params['sorting_dropdown_popularity_text']); ?>
															</li>
															<li class="<?php echo $sortby == 'rating' ? 'portfolio-sorting-select-current' : ''; ?>"
																data-orderby="rating"
																data-order="desc"><?php echo esc_html($params['sorting_dropdown_rating_text']); ?>
															</li>
															<li class="<?php echo $sortby == 'price' ? 'portfolio-sorting-select-current' : ''; ?>"
																data-orderby="price"
																data-order="asc"><?php echo esc_html($params['sorting_dropdown_price_low_high_text']); ?>
															</li>
															<li class="<?php echo $sortby == 'price-desc' ? 'portfolio-sorting-select-current' : ''; ?>"
																data-orderby="price"
																data-order="desc"><?php echo esc_html($params['sorting_dropdown_price_high_low_text']); ?>
															</li>
														</ul>
													</div>
												<?php endif; ?>

												<?php if ($params['filter_by_search'] == '1' && ($params['filters_style'] == 'standard' || $search_only)) { ?>
													<span>&nbsp;</span>
													<form class="portfolio-search-filter <?php echo $search_only ? 'mobile-visible' : ''; ?>"
														  role="search" action="">
														<div class="portfolio-search-filter-form">
															<input type="search"
																   placeholder="<?php echo esc_attr($params['filters_text_labels_search_text']); ?>"
																   value="<?php echo esc_attr($search_current); ?>">
														</div>
														<div class="portfolio-search-filter-button"></div>
													</form>
												<?php } ?>
											</div>
										<?php endif; ?>
									</div>
									<?php if ($params['product_show_filter'] == '1') {
										include(locate_template(array('gem-templates/products-extended/selected-filters.php')));
									} ?>
								</div>
							<?php endif; ?>
							<?php if ($params['product_show_filter'] == '1' && $params['filters_style'] == 'tabs'): ?>
								<div class="portfolio-top-panel">
									<div class="portfolio-filter-tabs style-<?php echo $params['filters_tabs_style']; ?> alignment-<?php echo $params['product_tabs_alignment']; ?> <?php echo $params['filters_tabs_title_separator'] == '1' ? 'separator' : ''; ?>">
										<?php if ($params['filters_tabs_title_text'] != '') { ?>
											<div class="title-h4 portfolio-filter-tabs-title <?php echo $params['filters_tabs_title_style_preset'] == 'thin' ? 'light' : ''; ?>"><?php echo $params['filters_tabs_title_text']; ?></div>
										<?php }
										$filter_tabs = vc_param_group_parse_atts($params['filters_tabs_tabs']);
										if (!empty($filter_tabs)) { ?>
											<ul class="portfolio-filter-tabs-list">
												<?php foreach ($filter_tabs as $index => $item) { ?>
													<li class="portfolio-filter-tabs-list-tab <?php echo $index == $active_tab - 1 ? 'active' : ''; ?>"
														data-num="<?php echo $index + 1; ?>"
														data-filter="<?php echo $item['filters_tabs_tab_filter_by'] ?>"
														data-filter-cat="<?php echo isset($item['filters_tabs_tab_products_cat']) ? $item['filters_tabs_tab_products_cat'] : ''; ?>">
														<?php echo $item['filters_tabs_tab_title'] ?>
													</li>
													<?php
												} ?>
											</ul>
										<?php } ?>
										<?php if ($params['pagination_type'] == 'arrows' && $params['filters_tabs_style'] == 'alternative'): ?>
											<div class="portfolio-navigator gem-pagination gem-pagination-arrows">
												<a href="" class="prev">
													<?php
													if (isset($params['pagination_arrows_left_pack']) && $params['pagination_arrows_left_icon_' . $params['pagination_arrows_left_pack']] != '') {
														echo thegem_build_icon($params['pagination_arrows_left_pack'], $params['pagination_arrows_left_icon_' . $params['pagination_arrows_left_pack']]);
													} else { ?>
														<i class="default"></i>
													<?php } ?>
												</a>
												<a href="" class="next"><?php
													if (isset($params['pagination_arrows_right_pack']) && $params['pagination_arrows_right_icon_' . $params['pagination_arrows_right_pack']] != '') {
														echo thegem_build_icon($params['pagination_arrows_right_pack'], $params['pagination_arrows_right_icon_' . $params['pagination_arrows_right_pack']]);
													} else { ?>
														<i class="default"></i>
													<?php } ?></a>
											</div>
										<?php endif; ?>
									</div>
								</div>
							<?php endif; ?>
							<div class="row portfolio-row">
								<div class="portfolio-set clearfix"
									 data-max-row-height="<?php echo $params['metro_max_row_height'] ? esc_attr($params['metro_max_row_height']) : ''; ?>">
									<?php
									if ($product_loop->have_posts()) {
										remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10);
										remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10);
										remove_action('woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
										remove_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10);
										remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5);
										remove_action('woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10);
										remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10);
										remove_action('woocommerce_after_shop_loop_item', 'thegem_woocommerce_after_shop_loop_item_link', 15);
										remove_action('woocommerce_after_shop_loop_item', 'thegem_woocommerce_after_shop_loop_item_wishlist', 20);
										while ($product_loop->have_posts()) : $product_loop->the_post(); ?>
											<?php echo thegem_extended_products_render_item($params, $item_classes, $thegem_sizes, get_the_ID()); ?>
										<?php
										endwhile;
										wp_reset_postdata();
									} else { ?>
										<div class="portfolio-item not-found">
											<div class="wrap clearfix">
												<div class="image-inner"></div>
												<?php echo esc_html($params['not_found_text']); ?>
											</div>
										</div>
									<?php } ?>
								</div><!-- .portflio-set -->
								<div class="portfolio-item-size-container">
									<?php echo thegem_extended_products_render_item($params, $item_classes); ?>
								</div>
							</div><!-- .row-->
							<?php

							/** Pagination */

							if ('1' === ($params['show_pagination'])) : ?>
								<?php if ($params['pagination_type'] == 'normal'): ?>
									<div class="portfolio-navigator gem-pagination">
										<a href="" class="prev"><i class="default"></i></a>
										<div class="pages"></div>
										<a href="" class="next"><i class="default"></i></a>
									</div>
								<?php endif; ?>
								<?php
								if ($params['pagination_type'] == 'more' && $next_page > 0):

									$separator_enabled = ($params['more_show_separator'] === '1' && $params['more_stretch_full_width'] !== '1') ? true : false;

									// Container
									$classes_container = 'gem-button-container gem-widget-button ';

									if ($separator_enabled) {
										$classes_container .= 'gem-button-position-center gem-button-with-separator ';
									} else {
										if ('1' === $params['more_stretch_full_width']) {
											$classes_container .= 'gem-button-position-fullwidth ';
										}
									}

									// Separator
									$classes_separator = 'gem-button-separator ';

									if (!empty($params['pagination_more_button_separator_style'])) {
										$classes_separator .= $params['pagination_more_button_separator_style'];
									}

									// Link
									$classes_button = "load-more-button gem-button gem-button-text-weight-" . $params['pagination_more_button_text_weight'] . " gem-button-size-" . $params['pagination_more_button_size'] . " gem-button-style-" . $params['pagination_more_button_type'];
									?>

									<div class="portfolio-load-more gem-pagination">
										<div class="inner">
											<?php include(locate_template(array('gem-templates/products-extended/more-button.php'))); ?>
										</div>
									</div>
								<?php endif; ?>
								<?php if ($params['pagination_type'] == 'scroll' && $next_page > 0): ?>
									<div class="portfolio-scroll-pagination gem-pagination"></div>
								<?php endif; ?>
							<?php endif; ?>
							<?php if ($params['pagination_type'] == 'arrows' && ($params['filters_style'] !== 'tabs' || $params['filters_tabs_style'] == 'default')): ?>
								<div class="portfolio-navigator gem-pagination gem-pagination-arrows alignment-<?php echo $params['product_tabs_alignment']; ?>">
									<a href="" class="prev"><i class="default"></i></a>
									<a href="" class="next"><i class="default"></i></a>
								</div>
							<?php endif; ?>

							<?php if ($params['product_show_filter'] == '1' && $params['filters_style'] == 'sidebar' && !$search_only) { ?>
						</div>
					</div>
				<?php } ?>
					<div class="thegem-popup-notification cart"
						 data-timing="<?php echo esc_attr($params['stay_visible']); ?>">
						<div class="notification-message">
							<?php echo esc_html($params['added_cart_text']); ?> <span class="buttons">
									<a class="button"
									   href="<?php echo esc_url(wc_get_cart_url()); ?>"><?php echo esc_html($params['view_cart_button_text']); ?></a>
									<a class="button"
									   href="<?php echo esc_url(wc_get_checkout_url()); ?>"><?php echo esc_html($params['checkout_button_text']); ?></a></span>
						</div>
					</div>
					<?php if (defined('YITH_WCWL') && $params['product_show_wishlist'] == '1') { ?>
						<div class="thegem-popup-notification wishlist-add"
							 data-timing="<?php echo esc_attr($params['stay_visible']); ?>">
							<div class="notification-message">
								<?php echo esc_html($params['added_wishlist_text']); ?> <span class="buttons">
										<a class="button"
										   href="<?php echo esc_url(YITH_WCWL()->get_wishlist_url()); ?>"><?php echo esc_html($params['view_wishlist_button_text']); ?></a>
									</span>
							</div>
						</div>
						<div class="thegem-popup-notification wishlist-remove"
							 data-timing="<?php echo esc_attr($params['stay_visible']); ?>">
							<div class="notification-message">
								<?php echo esc_html($params['removed_wishlist_text']); ?>
							</div>
						</div>
					<?php } ?>
				</div><!-- .full-width -->
			</div><!-- .portfolio-->
		</div><!-- .portfolio-preloader-wrapper-->
	<?php

	else: ?>
		<div class="bordered-box centered-box styled-subtitle">
			<?php echo esc_html__('Please select products in "Products" section', 'thegem') ?>
		</div>
	<?php endif;
	$post = $portfolio_posttemp;
}

